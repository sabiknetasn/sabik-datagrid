# sabik-datagrid

Reusable DataGrid for React 18+ and TypeScript, built on TanStack Table and TanStack Virtual.

## Features

- Client-side sorting, filtering, pagination, and row selection
- Optional row virtualization for large datasets
- Toolbar search, column visibility, and CSV export callback
- Row actions and bulk actions
- LocalStorage persistence scoped per `persistenceKey`
- Self-contained CSS (no Tailwind required)

## Installation

```bash
npm install sabik-datagrid
```

## Styles

Styles are injected automatically when the package is imported (no Tailwind setup required).

You can also import the stylesheet explicitly if needed:

```ts
import 'sabik-datagrid/styles.css';
```

## Quick Start

```tsx
import { DataGrid } from 'sabik-datagrid';

const columns = [
  { accessorKey: 'name', header: 'Name' },
  { accessorKey: 'email', header: 'Email' },
];

function App() {
  return (
    <DataGrid
      data={users}
      columns={columns}
      pagination
      searchable
      selectable
      toolbar
    />
  );
}
```

## API Reference

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `data` | `TData[]` | Required | Rows to display |
| `columns` | `DataGridColumnDef<TData>[]` | Required | Column definitions |
| `loading` | `boolean` | `false` | Show loading state |
| `error` | `Error \| string \| null` | `null` | Show error state |
| `searchable` | `boolean` | `false` | Global search input in toolbar |
| `filterable` | `boolean` | `false` | Reset-filters control in toolbar |
| `pagination` | `boolean` | `false` | Show pagination controls |
| `selectable` | `boolean` | `false` | Enable row selection |
| `exportable` | `boolean` | `false` | Show Export button (calls `onExport`) |
| `toolbar` | `boolean` | `false` | Show toolbar |
| `stickyHeader` | `boolean` | `false` | Constrain scroll area for sticky header use |
| `virtualized` | `boolean` | `false` | Virtualize rows (set when rendering many rows) |
| `persistenceKey` | `string` | `undefined` | Unique key for LocalStorage state (required for isolation across grids) |
| `rowActions` | `RowAction<TData>[]` | `undefined` | Per-row action menu |
| `bulkActions` | `RowAction<TData>[]` | `undefined` | Actions for selected rows |
| `onBulkAction` | `(action, rows) => void` | `undefined` | Bulk action handler |
| `onExport` | `(type) => void` | `undefined` | Called when Export is clicked |
| `manualPagination` | `boolean` | `false` | Disable client pagination |
| `manualSorting` | `boolean` | `false` | Disable client sorting |
| `manualFiltering` | `boolean` | `false` | Disable client filtering |
| `className` | `string` | `undefined` | Extra class on root |

### Column fields not implemented yet

These exist on `DataGridColumnDef` for forward compatibility but are **not applied** today:

- `pin`
- `editable`

### Types only

`DataGridTheme` is exported as a type but there is no theme prop yet.
