# @company/datagrid

Enterprise-grade, type-safe DataGrid for React 18+ and TypeScript.

## Features

- 🚀 **High Performance**: Integrated with TanStack Table v8 and TanStack Virtual.
- 🛠 **Server-Side Ready**: Support for manual pagination, sorting, and filtering.
- 📦 **Persistence**: LocalStorage synchronization for grid state.
- 🎨 **Modern UI**: Built with Tailwind CSS, SaaS-inspired design.
- ♿ **Accessible**: WCAG AA compliant with full keyboard navigation.
- 🔗 **URL Sync**: Synchronize grid state with React Router search params.

## Installation

```bash
npm install @company/datagrid
```

## Quick Start

```tsx
import { DataGrid } from '@company/datagrid';

const columns = [
  { accessorKey: 'name', header: 'Name' },
  { accessorKey 'email', header: 'Email' },
];

function App() {
  return (
    <DataGrid 
      data={users} 
      columns={columns} 
      pagination 
      searchable 
      selectable 
    />
  );
}
```

## API Reference

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `data` | `TData[]` | Required | The data to display |
| `columns` | `ColumnDef<TData>[]` | Required | Column definitions |
| `loading` | `boolean` | `false` | Show skeleton loading state |
| `selectable` | `boolean` | `false` | Enable row selection |
| `virtualized` | `boolean` | `false` | Enable virtualization for large sets |
| `persistenceKey` | `string` | `undefined` | Key for LocalStorage persistence |
| `urlSync` | `boolean` | `false` | Sync state to URL search params |
